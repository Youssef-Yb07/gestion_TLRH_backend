package com.tlrh.gestion_tlrh_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionTlrhBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
