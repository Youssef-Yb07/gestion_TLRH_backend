package com.tlrh.gestion_tlrh_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionTlrhBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestionTlrhBackendApplication.class, args);
    }

}
